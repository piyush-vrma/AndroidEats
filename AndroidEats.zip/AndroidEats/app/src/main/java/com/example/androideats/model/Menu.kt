package com.example.androideats.model

data class Menu(val menuId:String,val menuName:String,val cost:String,val restId:String) {
}