package com.example.androideats.model

data class Restaurant(var restId:String,var restName: String, var rating: String, var cost: String,var restImage:String){

}